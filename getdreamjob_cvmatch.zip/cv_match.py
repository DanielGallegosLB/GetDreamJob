# -*- coding: utf-8 -*-
"""
cv_match.py — Módulo independiente "CV Match" para DreamJob.

Qué hace:
  1. Lee tus CVs (.docx / .txt / .pdf) y extrae roles, años de experiencia y skills.
  2. Genera consultas de búsqueda a partir del CV (editables).
  3. Busca EMPLEOS reales en LinkedIn (API pública de invitados, sin login),
     con filtro de antigüedad, modalidad y nivel, y lee la descripción completa.
  4. Puntúa cada oferta (0-100) según su semejanza con tu CV.
  5. PUBLICACIONES: LinkedIn exige sesión para buscar posts, así que aquí se
     generan los enlaces de búsqueda y se pega el texto del post para puntuarlo.
  6. Seguimiento: estado (Nueva / Revisada / Postulada / Entrevista / ...) y notas,
     guardados en cv_match_data.json.

Se integra en app.py con:  import cv_match ; cv_match.render_tab()
No toca el motor ni los archivos JSON de la pestaña clásica.
"""
import hashlib
import io
import json
import logging
import os
import re
import time
import unicodedata
import zipfile
from datetime import date, datetime
from urllib.parse import quote_plus

import requests
from bs4 import BeautifulSoup

log = logging.getLogger("dreamjob.cvmatch")

DATA_FILE = "cv_match_data.json"
CV_DIR = "cvs"

ESTADOS = ["🆕 Nueva", "👀 Revisada", "📨 Postulada", "🗣️ Entrevista", "🎁 Oferta", "❌ Descartada"]
ESTADO_NUEVA = ESTADOS[0]
ESTADO_DESCARTADA = ESTADOS[-1]

# ─────────────────────────────────────────────
# 1. CATÁLOGO DE SKILLS (nombre → alias en regex, sin tildes y en minúscula)
# ─────────────────────────────────────────────
CATALOGO = {
    # Lenguajes
    "Python": r"python",
    "JavaScript": r"javascript|java\s?script|ecmascript|\bjs\b",
    "TypeScript": r"typescript|\bts\b",
    "Java": r"java",
    "PHP": r"php",
    "C++": r"c\+\+",
    "C#": r"c#|c\s?sharp",
    ".NET": r"\.net(?:\s?core)?|asp\.net|dotnet",
    "Golang": r"golang|go\s?lang",
    "Rust": r"rust",
    "Ruby": r"ruby(?:\s+on\s+rails)?|rails",
    "Kotlin": r"kotlin",
    "Scala": r"scala",
    # Frameworks
    "Node.js": r"node\.?\s?js|nodejs",
    "Express": r"express(?:\.?js)?",
    "NestJS": r"nest\.?js",
    "React": r"react(?:\.?js)?",
    "React Native": r"react\s?native",
    "Next.js": r"next\.?\s?js",
    "Vue": r"vue(?:\.?js)?",
    "Angular": r"angular(?:js)?",
    "Django": r"django",
    "Flask": r"flask",
    "FastAPI": r"fast\s?api",
    "Spring": r"spring(?:\s?boot)?",
    "Laravel": r"laravel",
    "Tailwind": r"tailwind(?:\s?css)?",
    "CSS": r"css",
    "HTML": r"html5?",
    # Bases de datos
    "MongoDB": r"mongo\s?db|mongo",
    "PostgreSQL": r"postgres(?:ql)?|postgre|psql",
    "MySQL": r"mysql|mariadb",
    "SQL Server": r"sql\s?server|mssql|t-?sql",
    "SQL": r"sql",
    "Oracle": r"oracle(?:\s?db|\s?database)?|pl/?sql",
    "Redis": r"redis",
    "ElasticSearch": r"elastic\s?search|opensearch|\belk\b",
    "NoSQL": r"no-?sql",
    # Cloud / DevOps
    "Google Cloud": r"google\s?cloud|gcp|bigquery|cloud\s?functions",
    "AWS": r"aws|amazon\s?web\s?services",
    "Azure": r"azure",
    "Serverless": r"serverless|lambda|azure\s?functions",
    "Docker": r"docker",
    "Kubernetes": r"kubernetes|k8s",
    "Git": r"git(?:hub|lab)?",
    "CI/CD": r"ci\s?/\s?cd|cicd|jenkins|github\s?actions|gitlab\s?ci",
    "Linux": r"linux|red\s?hat|rhel|ubuntu",
    "NGINX": r"nginx",
    "VMware": r"vmware",
    "Terraform": r"terraform",
    "Kafka": r"kafka",
    "RabbitMQ": r"rabbit\s?mq",
    # Integración / datos
    "REST": r"rest(?:ful)?",
    "APIs": r"apis?|web\s?services?",
    "SOAP": r"soap|wsdl",
    "GraphQL": r"graphql",
    "ETL": r"etl|elt",
    "Integraciones": r"integracion(?:es)?|integration(?:s)?",
    "Pipelines de datos": r"pipelines?|data\s?pipelines?",
    "Web scraping": r"scraping|scraper|crawler|crawling",
    "Selenium": r"selenium",
    "Postman": r"postman",
    "Testing": r"testing|pruebas|\bqa\b|test\s?automation|pytest|jest|unit\s?tests?",
    "Microservicios": r"microservicios|microservices?",
    "Middleware / ESB": r"middleware|mulesoft|wso2|tibco|boomi|\besb\b|\bsoa\b",
    "Airflow": r"airflow",
    "Spark": r"(?:py)?spark",
    "Pandas": r"pandas",
    "Power BI": r"power\s?bi|tableau",
    "Data Warehouse": r"data\s?warehouse|datawarehouse|\bdwh\b|snowflake|redshift",
    # Seguridad / metodologías
    "OWASP": r"owasp",
    "Scrum": r"scrum",
    "Agile": r"agile|agil",
    "Jira": r"jira",
    "Kanban": r"kanban",
}
_REGEX = {k: re.compile(r"(?<![\w+#.])(?:%s)(?![\w+#])" % v) for k, v in CATALOGO.items()}


def _sin_acentos(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t or "") if unicodedata.category(c) != "Mn")


def _norm(t: str) -> str:
    return _sin_acentos(t).lower()


def detectar_skills(texto: str, extras=None) -> list:
    """Devuelve las skills (del catálogo + extras literales) presentes en el texto."""
    n = _norm(texto)
    out = [k for k, rx in _REGEX.items() if rx.search(n)]
    for e in extras or []:
        e_n = _norm(e).strip()
        if e_n and re.search(r"(?<![\w+#.])%s(?![\w+#])" % re.escape(e_n), n):
            out.append(e)
    return out


# ─────────────────────────────────────────────
# 2. LECTURA Y ANÁLISIS DEL CV
# ─────────────────────────────────────────────
def docx_a_texto(data: bytes) -> str:
    """Extrae el texto de un .docx sin dependencias externas."""
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        xml = z.read("word/document.xml").decode("utf-8", errors="ignore")
    lineas = []
    for p in re.findall(r"<w:p[ >].*?</w:p>", xml, flags=re.S):
        partes = re.findall(r"<w:t[^>]*>(.*?)</w:t>|<w:tab/>|<w:br/>", p, flags=re.S)
        txt = "".join(partes)
        txt = (txt.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                  .replace("&quot;", '"').replace("&apos;", "'"))
        if txt.strip():
            lineas.append(txt.strip())
    return "\n".join(lineas)


def archivo_a_texto(nombre: str, data: bytes) -> str:
    ext = nombre.lower().rsplit(".", 1)[-1]
    if ext == "docx":
        return docx_a_texto(data)
    if ext == "pdf":
        try:
            from pypdf import PdfReader  # opcional
            return "\n".join((pg.extract_text() or "") for pg in PdfReader(io.BytesIO(data)).pages)
        except Exception as e:
            raise RuntimeError(f"Para leer PDF instala pypdf (pip install pypdf): {e}")
    return data.decode("utf-8", errors="ignore")


# Roles que se reconocen en el CV → (español, inglés) para las consultas
ROL_TRAD = {
    "backenddeveloper": ("Desarrollador Backend", "Backend Developer"),
    "desarrolladorbackend": ("Desarrollador Backend", "Backend Developer"),
    "frontenddeveloper": ("Desarrollador Frontend", "Frontend Developer"),
    "fullstackdeveloper": ("Desarrollador Full Stack", "Full Stack Developer"),
    "desarrolladorfullstack": ("Desarrollador Full Stack", "Full Stack Developer"),
    "integrationengineer": ("Ingeniero de Integración", "Integration Engineer"),
    "dataengineer": ("Ingeniero de Datos", "Data Engineer"),
    "dataanalyst": ("Analista de Datos", "Data Analyst"),
    "softwareengineer": ("Ingeniero de Software", "Software Engineer"),
    "softwaredeveloper": ("Desarrollador de Software", "Software Developer"),
    "devopsengineer": ("Ingeniero DevOps", "DevOps Engineer"),
    "cloudengineer": ("Ingeniero Cloud", "Cloud Engineer"),
    "qaengineer": ("Ingeniero QA", "QA Engineer"),
}
_ROL_RX = re.compile(
    r"\b(?:application\s+)?(?:integration|data|devops|software|cloud|qa)\s+(?:engineer|developer|analyst)"
    r"|\b(?:back\s?-?\s?end|front\s?-?\s?end|full\s?-?\s?stack)\s+(?:developer|engineer)"
    r"|\bdesarrollador(?:a)?\s+(?:back\s?-?\s?end|front\s?-?\s?end|full\s?-?\s?stack)",
    re.I,
)
_SECCIONES = [
    ("exp", r"(experience|experiencia|work experience|experiencia laboral)\b"),
    ("proy", r"(featured projects|projects|proyectos)\b"),
    ("stack", r"(tech stack|technical skills|skills|stack tecnico|habilidades|tecnologias)\b"),
    ("edu", r"(education|educacion|formacion|certificaciones)\b"),
    ("about", r"(about me|about|sobre mi|perfil|summary|resumen)\b"),
]


def _rol_key(r: str) -> str:
    return re.sub(r"[\s\-]+", "", _norm(r))


def analizar_cv(texto: str, nombre: str = "") -> dict:
    lineas = [l for l in texto.splitlines() if l.strip()]
    # roles (conserva el texto tal como aparece en el CV, sin duplicados)
    roles, vistos = [], set()
    for m in _ROL_RX.finditer(_sin_acentos(texto)):
        lit = re.sub(r"\s+", " ", m.group(0)).strip()
        lit = " ".join(w.capitalize() if w.islower() else w for w in lit.split())
        k = _rol_key(lit)
        if k not in vistos:
            vistos.add(k)
            roles.append(lit)
    # años de experiencia
    anios = 0
    for m in re.finditer(r"(\d{1,2})\s*\+?\s*(?:anos|years)", _norm(texto)):
        anios = max(anios, int(m.group(1)))
    # secciones (encabezados en MAYÚSCULAS)
    secciones, actual = {}, None
    for l in lineas:
        n = _norm(l).strip()
        if len(n) < 40 and l.strip() == l.strip().upper() and re.search(r"[A-Za-z]", l):
            hit = next((nom for nom, rx in _SECCIONES if re.match(rx, n)), None)
            if hit:
                actual = hit
                secciones.setdefault(hit, [])
                continue
        if actual:
            secciones[actual].append(l)
    skills = detectar_skills(texto)
    texto_exp = "\n".join(secciones.get("exp", []) + secciones.get("proy", []))
    skills_exp = detectar_skills(texto_exp)
    # extras: elementos del stack que no están en el catálogo
    extras = []
    for l in secciones.get("stack", []):
        l = l.split(":", 1)[1] if ":" in l else l
        l = re.sub(r"\([^)]*\)", "", l)
        for t in re.split(r"\s*(?:·|•|\||,|;|\s[–-]\s)\s*", l):
            t = t.strip(" .")
            if 1 < len(t) < 30 and not detectar_skills(t) and t not in extras:
                extras.append(t)
    return {"archivo": nombre, "roles": roles, "anios": anios, "skills": skills,
            "skills_exp": skills_exp, "extras": extras}


def combinar_cvs(perfiles: list) -> dict:
    def union(campo):
        out = []
        for p in perfiles:
            for x in p.get(campo, []):
                if x not in out:
                    out.append(x)
        return out
    return {"roles": union("roles"), "anios": max([p.get("anios", 0) for p in perfiles] or [0]),
            "skills": union("skills"), "skills_exp": union("skills_exp"), "extras": union("extras")}


def generar_queries(cv: dict) -> list:
    """Consultas de búsqueda (español + inglés) a partir de los roles y skills del CV."""
    qs, ya = [], set()
    roles = sorted(cv.get("roles", []), key=lambda r: len(r))  # los más cortos primero (genéricos)
    claves = [_rol_key(r) for r in roles]
    for r, k in zip(roles, claves):
        # "applicationintegrationengineer" ya está cubierto por "integrationengineer"
        if any(k != o and o in k for o in claves):
            continue
        es, en = ROL_TRAD.get(k, (r, r))
        for q in (es, en):
            if q.lower() not in ya:
                ya.add(q.lower())
                qs.append(q)
    base = "Backend" if any("back" in k for k in claves) else (qs[0] if qs else "Developer")
    for s in [x for x in ["Node.js", "Python", "PHP", "Java", "Golang", "React"] if x in cv.get("skills_exp", [])][:3]:
        q = f"{base} {s}"
        if q.lower() not in ya:
            ya.add(q.lower())
            qs.append(q)
    return qs or ["Developer"]


# ─────────────────────────────────────────────
# 3. PUNTAJE DE SEMEJANZA (0-100)
#    Título 40 · Skills 45 · Nivel/experiencia 15
# ─────────────────────────────────────────────
_GENERICO = r"developer|desarrollador|desarrolladora|engineer|ingeniero|ingeniera|programador|analista|analyst"
_GRUPOS_ROL = {
    "backend": r"back\s?-?end|backend|\bapi\b|servidor|server",
    "integracion": r"integra",
    "datos": r"\bdata\b|datos|\betl\b|\bbi\b",
    "fullstack": r"full\s?-?stack",
    "software": r"software",
}
_SENIOR = r"\bsenior\b|\bsr\b|\bsr\.|\blead\b|\bprincipal\b|\bstaff\b|\bhead\b|\bjefe\b|\bmanager\b|\barquitect|\barchitect|\bgerente\b|\bdirector\b|\blider\b|tech lead"
_JUNIOR = r"\bjunior\b|\bjr\b|\bjr\.|trainee|practicante|\bintern\b|internship|\bpractica\b"
_SEMI = r"semi\s?-?\s?senior|\bssr\b|\bsemi\b|\bmid\b|intermedio"


def _grupos_cv(cv: dict) -> set:
    claves = " ".join(_rol_key(r) for r in cv.get("roles", []))
    g = set()
    if "backend" in claves:
        g.add("backend")
    if "integration" in claves:
        g.add("integracion")
    if "data" in claves:
        g.add("datos")
    if "fullstack" in claves:
        g.add("fullstack")
    if "software" in claves:
        g.add("software")
    return g or {"software"}


def _pts_titulo(titulo_n: str, cv: dict, skills_cv: set) -> tuple:
    gcv = _grupos_cv(cv)
    espec = [g for g in gcv if re.search(_GRUPOS_ROL[g], titulo_n)]
    generico = bool(re.search(_GENERICO, titulo_n))
    skill_en_titulo = [s for s in detectar_skills(titulo_n) if s in skills_cv]
    solo_front = bool(re.search(r"front\s?-?end|frontend", titulo_n)) and "fullstack" not in espec
    if espec and generico:
        pts, razon = 40, f"rol afín ({', '.join(espec)})"
    elif espec:
        pts, razon = 30, f"rol afín ({', '.join(espec)})"
    elif generico:
        pts, razon = 18, "cargo técnico genérico"
    else:
        pts, razon = 0, "cargo sin relación clara"
    if skill_en_titulo and pts < 40:
        pts = min(40, pts + 8)
        razon += f" + skill en título ({', '.join(skill_en_titulo[:2])})"
    if solo_front:
        pts = min(pts, 8 if "fullstack" not in gcv else 14)
        razon = "orientado a frontend"
    return pts, razon


def _anios_requeridos(desc_n: str):
    vals = []
    for m in re.finditer(r"(\d{1,2})\s*\+?\s*(?:a\s*\d{1,2}\s*)?(?:anos|years)\s+(?:de\s+|of\s+)?(?:experiencia|experience)", desc_n):
        vals.append(int(m.group(1)))
    for m in re.finditer(r"experiencia\s+(?:minima\s+)?(?:de\s+)?(\d{1,2})\s*\+?\s*anos", desc_n):
        vals.append(int(m.group(1)))
    vals = [v for v in vals if 0 < v <= 12]
    return min(vals) if vals else None


def puntuar(titulo: str, desc: str, cv: dict, skills_sel=None, anios=None, extras=None) -> dict:
    """Puntúa una oferta (o publicación) contra el CV. Devuelve el desglose completo."""
    skills_cv = set(skills_sel if skills_sel is not None else cv.get("skills", []))
    exp = set(cv.get("skills_exp", []))
    anios = cv.get("anios", 0) if anios is None else anios
    titulo_n, desc_n = _norm(titulo), _norm(desc or "")
    texto = f"{titulo}\n{desc or ''}"

    pts_t, razon_t = _pts_titulo(titulo_n, cv, skills_cv)

    oferta_sk = detectar_skills(texto, extras)
    coinciden = [s for s in oferta_sk if s in skills_cv or s in (extras or [])]
    faltan = [s for s in oferta_sk if s not in coinciden]
    sin_desc = len(desc or "") < 200
    if oferta_sk:
        m = sum(2 if s in exp else 1 for s in coinciden)
        f = len(faltan)
        cobertura = min(1.0, 1.15 * m / (m + f + 1.5))
        pts_s = round(45 * cobertura, 1)
    else:
        pts_s = 0.0

    senior = bool(re.search(_SENIOR, titulo_n)) and not re.search(_SEMI, titulo_n)
    junior = bool(re.search(_JUNIOR, titulo_n))
    req = _anios_requeridos(desc_n)
    if req is not None:
        pts_n = 15 if req <= anios + 1 else (8 if req == anios + 2 else 0)
        razon_n = f"pide {req}+ años (tienes {anios})"
    elif re.search(_SEMI, titulo_n):
        pts_n, razon_n = 15, "nivel semi-senior"
    elif junior:
        pts_n, razon_n = 10, "nivel junior"
    else:
        pts_n, razon_n = 12, "nivel no especificado"
    penal = 0
    if senior:
        pts_n = min(pts_n, 3)
        razon_n = "cargo senior/lead"
        if anios < 5:
            penal = 10

    total = max(0, min(100, round(pts_t + pts_s + pts_n - penal)))
    return {
        "puntaje": total, "pts_titulo": pts_t, "pts_skills": pts_s, "pts_nivel": pts_n, "penal": penal,
        "razon_titulo": razon_t, "razon_nivel": razon_n,
        "coinciden": coinciden, "faltan": faltan, "sin_desc": sin_desc, "anios_req": req,
    }


# ─────────────────────────────────────────────
# 4. LINKEDIN (API pública de invitados, sin login)
# ─────────────────────────────────────────────
HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
    "Accept-Language": "es-CL,es;q=0.9,en;q=0.8",
}
URL_BUSCAR = "https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search"
URL_DETALLE = "https://www.linkedin.com/jobs-guest/jobs/api/jobPosting/{id}"

ANTIGUEDAD = {"Últimas 24 horas": 86400, "Últimos 3 días": 259200, "Última semana": 604800,
              "Últimas 2 semanas": 1209600, "Último mes": 2592000}
MODALIDAD = {"Presencial": "1", "Remoto": "2", "Híbrido": "3"}
NIVEL = {"Prácticas": "1", "Júnior": "2", "Asociado": "3", "Intermedio-Senior": "4", "Director": "5"}


def _get(url, params=None, intentos=3):
    """GET con reintentos. Devuelve (texto|None, status)."""
    status = None
    for i in range(intentos):
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=20)
            status = r.status_code
            if r.status_code == 200:
                return r.text, 200
            if r.status_code in (429, 999):
                time.sleep(4 * (i + 1))
                continue
            if r.status_code in (400, 404):
                return None, r.status_code
            time.sleep(2)
        except requests.RequestException as e:
            log.warning(f"LinkedIn red: {e}")
            time.sleep(2)
    return None, status


def parsear_tarjetas(html: str) -> list:
    """Convierte el HTML de resultados de LinkedIn en una lista de ofertas."""
    soup = BeautifulSoup(html, "html.parser")
    out = []
    for li in soup.find_all("li"):
        card = li.find("div", class_=re.compile("base-card")) or li
        titulo_el = card.find("h3")
        if not titulo_el:
            continue
        titulo = titulo_el.get_text(" ", strip=True)
        link = card.find("a", class_=re.compile("base-card__full-link")) or card.find("a", href=True)
        href = link["href"].split("?")[0] if link and link.get("href") else ""
        m = re.search(r"jobPosting:(\d+)", card.get("data-entity-urn", "") or "") or re.search(r"-(\d{8,})$", href)
        if not m or not titulo:
            continue
        jid = m.group(1)
        emp_el = card.find("h4") or card.find("a", class_=re.compile("hidden-nested-link"))
        loc_el = card.find("span", class_=re.compile("job-search-card__location"))
        t_el = card.find("time")
        out.append({
            "id": jid, "tipo": "empleo", "titulo": titulo,
            "empresa": emp_el.get_text(" ", strip=True) if emp_el else "",
            "lugar": loc_el.get_text(" ", strip=True) if loc_el else "",
            "fecha": (t_el.get("datetime", "") if t_el else "")[:10],
            "url": f"https://www.linkedin.com/jobs/view/{jid}",
        })
    return out


def parsear_detalle(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    d = soup.find("div", class_=re.compile("show-more-less-html__markup")) or soup.find("section", class_=re.compile("description"))
    desc = d.get_text("\n", strip=True) if d else ""
    crit = {}
    for it in soup.find_all("li", class_=re.compile("description__job-criteria-item")):
        h, s = it.find("h3"), it.find("span")
        if h and s:
            crit[h.get_text(strip=True)] = s.get_text(strip=True)
    post = soup.find(class_=re.compile("num-applicants__caption"))
    return {"desc": desc, "criterios": crit, "postulantes": post.get_text(strip=True) if post else ""}


def buscar_empleos(queries, ubicacion, tpr_seg, paginas, modalidades, niveles, progreso=None) -> tuple:
    """Busca cada consulta en LinkedIn. Devuelve (ofertas_unicas, avisos)."""
    ofertas, ids, avisos = [], set(), []
    total_pasos = max(1, len(queries) * paginas)
    paso = 0
    for q in queries:
        start = 0
        for pg in range(paginas):
            paso += 1
            if progreso:
                progreso(f"🔍 «{q}» — página {pg + 1}/{paginas}", paso / total_pasos)
            params = {"keywords": q, "location": ubicacion, "start": start, "f_TPR": f"r{tpr_seg}", "sortBy": "DD"}
            if modalidades:
                params["f_WT"] = ",".join(MODALIDAD[m] for m in modalidades)
            if niveles:
                params["f_E"] = ",".join(NIVEL[n] for n in niveles)
            html, status = _get(URL_BUSCAR, params)
            if html is None:
                avisos.append(f"«{q}» p.{pg + 1}: LinkedIn respondió {status or 'sin conexión'}")
                break
            tarjetas = parsear_tarjetas(html)
            if not tarjetas:
                break
            nuevas = 0
            for t in tarjetas:
                if t["id"] not in ids:
                    ids.add(t["id"])
                    t["query"] = q
                    ofertas.append(t)
                    nuevas += 1
            start += len(tarjetas)
            if nuevas == 0:
                break
            time.sleep(1.2)
    return ofertas, avisos


def leer_detalles(ofertas: list, limite: int, progreso=None) -> int:
    """Descarga la descripción completa de hasta `limite` ofertas que aún no la tienen."""
    pend = [o for o in ofertas if not o.get("desc")][:limite]
    for i, o in enumerate(pend, 1):
        if progreso:
            progreso(f"📄 Leyendo descripción {i}/{len(pend)}: {o.get('titulo', '')[:50]}", i / max(1, len(pend)))
        html, status = _get(URL_DETALLE.format(id=o["id"]), intentos=2)
        if html:
            det = parsear_detalle(html)
            o["desc"] = det["desc"]
            o["criterios"] = det["criterios"]
            o["postulantes"] = det["postulantes"]
        time.sleep(1.0)
    return len(pend)


# ─────────────────────────────────────────────
# 5. PERSISTENCIA Y SEGUIMIENTO
# ─────────────────────────────────────────────
def cargar() -> dict:
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, encoding="utf-8") as f:
                d = json.load(f)
            d.setdefault("cfg", {})
            d.setdefault("items", {})
            d.setdefault("eliminadas", [])
            return d
        except Exception as e:
            log.error(f"No se pudo leer {DATA_FILE}: {e}")
    return {"cfg": {}, "items": {}, "eliminadas": []}


def guardar(data: dict):
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, DATA_FILE)


def integrar(data: dict, nuevos: list) -> int:
    """Agrega ofertas nuevas sin pisar el estado ni las notas de las que ya existen."""
    items, agregados = data["items"], 0
    hoy = datetime.now().isoformat(timespec="seconds")
    borradas = set(data.get("eliminadas", []))
    for o in nuevos:
        key = f"{o.get('tipo', 'empleo')}:{o['id']}"
        if key in borradas:  # la eliminaste: no vuelve a aparecer en nuevas búsquedas
            continue
        if key in items:
            ex = items[key]
            for c in ("titulo", "empresa", "lugar", "fecha", "desc", "criterios", "postulantes"):
                if o.get(c) and not ex.get(c):
                    ex[c] = o[c]
        else:
            o = dict(o)
            o.update({"estado": ESTADO_NUEVA, "notas": "", "encontrada": hoy, "fecha_estado": hoy})
            items[key] = o
            agregados += 1
    return agregados


def repuntuar(data: dict, cv: dict, skills_sel, anios, extras):
    for it in data["items"].values():
        r = puntuar(it.get("titulo", ""), it.get("desc", ""), cv, skills_sel, anios, extras)
        it["score"] = r


def dias_desde(fecha_iso: str):
    try:
        return (date.today() - datetime.strptime(fecha_iso[:10], "%Y-%m-%d").date()).days
    except Exception:
        return None


# ─────────────────────────────────────────────
# 6. PUBLICACIONES
# ─────────────────────────────────────────────
_HIRING = r"contratando|estamos buscando|buscamos|vacante|we are hiring|we're hiring|hiring|join our team|nos expandimos|oportunidad laboral|postula"
PERIODOS_POST = {"Últimas 24 horas": "past-24h", "Última semana": "past-week", "Último mes": "past-month"}


def urls_busqueda_posts(queries, periodo: str) -> list:
    out = []
    for q in queries:
        kw = quote_plus(f'(contratando OR hiring OR buscamos) "{q}"')
        out.append((q, "https://www.linkedin.com/search/results/content/?keywords=" + kw +
                    f"&datePosted=%22{periodo}%22&sortBy=%22date_posted%22"))
    return out


def analizar_publicacion(texto: str) -> dict:
    n = _norm(texto)
    return {"contratando": bool(re.search(_HIRING, n)),
            "emails": sorted(set(re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", texto)))}


# ─────────────────────────────────────────────
# 7. FECHAS, FILTROS Y LIMPIEZA (lógica sin interfaz)
# ─────────────────────────────────────────────
GRUPOS_ESTADO = {
    "Activas": [e for e in ESTADOS if e != ESTADO_DESCARTADA],
    "Por revisar": [ESTADOS[0]],
    "Revisadas": [ESTADOS[1]],
    "Postuladas": [ESTADOS[2]],
    "En proceso": [ESTADOS[3], ESTADOS[4]],
    "Descartadas": [ESTADO_DESCARTADA],
    "Todas": list(ESTADOS),
}
FILTRO_DIAS = {"Hoy / ayer": 1, "3 días": 3, "1 semana": 7, "2 semanas": 14, "1 mes": 31, "Todas": None}
FILTRO_PUNTAJE = {"🔥 70+": 70, "👍 50+": 50, "Todas": 0}


def fecha_ef(it: dict):
    """(fecha_iso, aproximada). Si LinkedIn no dio fecha se usa el día en que se encontró (aprox.)."""
    f = (it.get("fecha") or "")[:10]
    if f:
        return f, False
    return (it.get("encontrada") or "")[:10], True


def hace_txt(dias) -> str:
    if dias is None:
        return "—"
    ico = "🟢" if dias <= 3 else ("🟡" if dias <= 14 else "🔴")
    if dias <= 0:
        t = "hoy"
    elif dias == 1:
        t = "ayer"
    elif dias < 14:
        t = f"hace {dias} días"
    elif dias < 60:
        t = f"hace {dias // 7} sem"
    else:
        t = f"hace {dias // 30} meses"
    return f"{ico} {t}"


def filas(data: dict) -> list:
    out = []
    for key, it in data["items"].items():
        tipo = it.get("tipo", "empleo")
        f, aprox = fecha_ef(it)
        dias = dias_desde(f)
        sc = it.get("score", {})
        out.append({
            "Sel": False, "_key": key, "Puntaje": sc.get("puntaje", 0),
            "Estado": it.get("estado", ESTADO_NUEVA), "Hace": hace_txt(dias),
            "Publicada": (f or "—") + (" ~" if aprox and f else ""),
            "Tipo": "💼 Empleo" if tipo == "empleo" else "💬 Post",
            "Título": (it.get("titulo") or "")[:140], "Empresa": it.get("empresa", ""), "Lugar": it.get("lugar", ""),
            "Coincide": ", ".join(sc.get("coinciden", [])[:8]), "Notas": it.get("notas", ""), "Link": it.get("url", ""),
            "_dias": dias if dias is not None else 9999, "_fest": it.get("fecha_estado", ""), "_tipo": tipo,
        })
    return out


def filtrar_df(df, minimo=0, dias_max=None, tipo="Todo", grupo="Activas", texto="", orden="Mejor puntaje"):
    """Aplica los filtros rápidos de la pestaña Resultados."""
    if df.empty:
        return df
    m = (df["Puntaje"] >= minimo) & df["Estado"].isin(GRUPOS_ESTADO[grupo])
    if dias_max is not None:
        m &= df["_dias"] <= dias_max
    if tipo == "Empleos":
        m &= df["_tipo"] == "empleo"
    elif tipo == "Publicaciones":
        m &= df["_tipo"] == "publicacion"
    if texto.strip():
        t = _norm(texto.strip())
        base = (df["Título"] + " " + df["Empresa"] + " " + df["Lugar"] + " " + df["Coincide"]).map(_norm)
        m &= base.str.contains(re.escape(t), regex=True)
    df = df[m]
    if orden == "Más recientes":
        return df.sort_values(["_dias", "Puntaje"], ascending=[True, False])
    return df.sort_values(["Puntaje", "_dias"], ascending=[False, True])


def eliminar(data: dict, keys, recordar=True) -> int:
    """Borra ítems. Con recordar=True los empleos no vuelven a aparecer en próximas búsquedas."""
    n = 0
    for k in list(keys):
        if data["items"].pop(k, None) is not None:
            n += 1
            if recordar and k.startswith("empleo:") and k not in data["eliminadas"]:
                data["eliminadas"].append(k)
    return n


def marcar(data: dict, keys, estado: str) -> int:
    ahora = datetime.now().isoformat(timespec="seconds")
    n = 0
    for k in keys:
        it = data["items"].get(k)
        if it and it.get("estado") != estado:
            it["estado"], it["fecha_estado"] = estado, ahora
            n += 1
    return n


def dividir_posts(texto: str) -> list:
    """Varios posts pegados juntos se separan con una línea '---'."""
    return [p.strip() for p in re.split(r"\n\s*-{3,}\s*\n", texto.strip()) if p.strip()]


# ─────────────────────────────────────────────
# 8. INTERFAZ STREAMLIT
# ─────────────────────────────────────────────
def _cargar_perfiles(st, subidos) -> list:
    os.makedirs(CV_DIR, exist_ok=True)
    for f in subidos or []:  # guarda los subidos para que persistan entre sesiones
        with open(os.path.join(CV_DIR, f.name), "wb") as out:
            out.write(f.getbuffer())
    perfiles = []
    for nombre in sorted(os.listdir(CV_DIR)):
        if nombre.startswith("~$") or nombre.rsplit(".", 1)[-1].lower() not in ("docx", "pdf", "txt"):
            continue
        try:
            with open(os.path.join(CV_DIR, nombre), "rb") as fh:
                perfiles.append(analizar_cv(archivo_a_texto(nombre, fh.read()), nombre))
        except Exception as e:
            st.warning(f"No pude leer {nombre}: {e}")
    return perfiles


def _refrescar(st, data):
    guardar(data)
    st.session_state["cvm_ver"] = st.session_state.get("cvm_ver", 0) + 1
    st.rerun()


def _tabla(st, df, seleccionar_todo=False, alto=470):
    """Tabla editable: Sel (casilla), Estado y Notas. Devuelve la tabla editada."""
    cols = ["Sel", "Puntaje", "Estado", "Hace", "Publicada", "Tipo", "Título", "Empresa", "Lugar", "Coincide", "Notas", "Link", "_key"]
    vista = df[cols].copy().reset_index(drop=True)
    vista["Sel"] = bool(seleccionar_todo)
    cfg = {
        "_key": None,
        "Sel": st.column_config.CheckboxColumn("✔", width="small", help="Marca filas para aplicarles una acción"),
        "Puntaje": st.column_config.ProgressColumn("Match", min_value=0, max_value=100, format="%d", width="small"),
        "Estado": st.column_config.SelectboxColumn("Estado", options=ESTADOS, required=True, width="small"),
        "Hace": st.column_config.TextColumn("Hace", width="small"),
        "Publicada": st.column_config.TextColumn("Fecha", width="small", help="~ = fecha aproximada (día en que la encontré)"),
        "Tipo": st.column_config.TextColumn("Tipo", width="small"),
        "Título": st.column_config.TextColumn("Título", width="large"),
        "Link": st.column_config.LinkColumn("Link", display_text="Abrir →", width="small"),
        "Notas": st.column_config.TextColumn("Notas", width="medium"),
    }
    bloq = [c for c in cols if c not in ("Sel", "Estado", "Notas")]
    sig = hashlib.md5(("|".join(vista["_key"]) + str(seleccionar_todo)).encode()).hexdigest()[:8]
    ver = st.session_state.get("cvm_ver", 0)
    return st.data_editor(vista, column_config=cfg, disabled=bloq, hide_index=True,
                          use_container_width=True, height=alto, key=f"cvm_tabla_{ver}_{sig}")


def _guardar_ediciones(st, data, ed):
    """Persiste los cambios de Estado/Notas hechos directamente en la tabla."""
    cambios, ahora = 0, datetime.now().isoformat(timespec="seconds")
    for _, f in ed.iterrows():
        it = data["items"].get(f["_key"])
        if not it:
            continue
        if f["Estado"] != it.get("estado"):
            it["estado"], it["fecha_estado"] = f["Estado"], ahora
            cambios += 1
        notas = f["Notas"] if isinstance(f["Notas"], str) else ""
        if notas != it.get("notas", ""):
            it["notas"] = notas
            cambios += 1
    if cambios:
        _refrescar(st, data)


def _detalle(st, data, keys):
    if not keys:
        return
    with st.expander("🔎 Ver detalle de una oferta (por qué tiene ese puntaje)"):
        def fmt(k):
            it = data["items"][k]
            return f"{it.get('score', {}).get('puntaje', 0):>3} pts · {it.get('titulo', '')[:70]} — {it.get('empresa', '')}"
        sel = st.selectbox("Oferta", keys, format_func=fmt, key="cvm_det_sel")
        it = data["items"][sel]
        sc = it.get("score", {})
        f, aprox = fecha_ef(it)
        st.caption(f"📅 Publicada: {f or '—'}{' (aprox.)' if aprox else ''} · {hace_txt(dias_desde(f))}"
                   + (f" · 👥 {it['postulantes']}" if it.get("postulantes") else ""))
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total", f"{sc.get('puntaje', 0)}/100")
        c2.metric("Título", f"{sc.get('pts_titulo', 0)}/40", help=sc.get("razon_titulo", ""))
        c3.metric("Skills", f"{sc.get('pts_skills', 0)}/45")
        c4.metric("Nivel", f"{sc.get('pts_nivel', 0)}/15", help=sc.get("razon_nivel", ""))
        st.caption(f"Título: {sc.get('razon_titulo', '')} · Nivel: {sc.get('razon_nivel', '')}"
                   + (f" · Penalización: -{sc['penal']}" if sc.get("penal") else ""))
        if sc.get("sin_desc"):
            st.warning("Sin descripción completa: el puntaje de skills es parcial.")
        st.markdown(f"✅ **Coinciden:** {', '.join(sc.get('coinciden', [])) or '—'}")
        st.markdown(f"➖ **Pide y no tienes marcado:** {', '.join(sc.get('faltan', [])) or '—'}")
        if it.get("criterios"):
            st.caption(" · ".join(f"{k}: {v}" for k, v in it["criterios"].items()))
        st.text_area("Descripción", it.get("desc", "") or "(sin descripción)", height=220, disabled=True, key=f"cvm_desc_{sel}")
        if it.get("url"):
            st.markdown(f"🔗 [Abrir]({it['url']})")


def render_tab():
    import pandas as pd
    import streamlit as st

    data = cargar()
    cfg = data["cfg"]
    st.subheader("📄 CV Match — empleos y publicaciones de LinkedIn según tu CV")

    hay_cv = os.path.isdir(CV_DIR) and any(not n.startswith("~$") for n in os.listdir(CV_DIR))
    with st.expander("📄 Mis CVs (sube o cambia tu CV aquí)", expanded=not hay_cv):
        subidos = st.file_uploader("CVs (.docx, .pdf, .txt) — se guardan en la carpeta cvs/", type=["docx", "pdf", "txt"],
                                   accept_multiple_files=True, key="cvm_up")
    perfiles = _cargar_perfiles(st, subidos)
    if not perfiles:
        st.info("Sube al menos un CV para empezar.")
        return
    cv = combinar_cvs(perfiles)

    t_bus, t_res, t_pub = st.tabs(["🔎 1. Buscar empleos", "📋 2. Resultados y seguimiento", "💬 3. Agregar publicaciones"])

    # ═════════ 1. BUSCAR ═════════
    with t_bus:
        qs_auto = generar_queries(cv)
        custom_txt = cfg.get("queries_custom", "")
        custom = [x.strip() for x in custom_txt.split(",") if x.strip()]
        opciones_q = qs_auto + [c for c in custom if c not in qs_auto]
        previo_q = [q for q in cfg.get("queries", []) if q in opciones_q]
        st.markdown("**¿Qué buscar?** (generado desde tu CV; quita o agrega lo que quieras)")
        queries = st.multiselect("Consultas", opciones_q, default=previo_q or qs_auto[:4], key="cvm_qs", label_visibility="collapsed")
        c1, c2 = st.columns(2)
        ant_lbl = c1.selectbox("Publicadas en", list(ANTIGUEDAD), index=list(ANTIGUEDAD).index(cfg.get("antiguedad", "Última semana")), key="cvm_ant")
        ubic = c2.text_input("Ubicación", value=cfg.get("ubicacion", "Chile"), key="cvm_ubic")
        zona_boton = st.container()

        with st.expander("⚙️ Más opciones (modalidad, nivel, páginas, consultas propias)"):
            custom_txt = st.text_input("Consultas propias (separadas por coma)", value=custom_txt, key="cvm_qcustom")
            o1, o2 = st.columns(2)
            modal = o1.multiselect("Modalidad (vacío = todas)", list(MODALIDAD), default=cfg.get("modalidad", []), key="cvm_mod")
            nivel = o2.multiselect("Nivel (vacío = todos)", list(NIVEL), default=cfg.get("nivel", ["Júnior", "Asociado", "Intermedio-Senior"]), key="cvm_niv")
            o3, o4, o5 = st.columns(3)
            pags = o3.number_input("Páginas por consulta", 1, 8, int(cfg.get("paginas", 3)), key="cvm_pags")
            leer = o4.checkbox("Leer descripción completa", value=cfg.get("leer", True), key="cvm_leer",
                               help="Más lento, pero el puntaje es mucho más preciso")
            limite = o5.number_input("Máx. descripciones a leer", 5, 300, int(cfg.get("limite", 60)), key="cvm_lim")

        with st.expander(f"🧩 Mi perfil ({len(cv['skills'])} skills · {cv['anios']} años) — skills que cuentan para el puntaje"):
            for p in perfiles:
                st.caption(f"📄 {p['archivo']} — roles: {', '.join(p['roles']) or '—'}")
            opciones_sk = cv["skills"] + [e for e in cv["extras"] if e not in cv["skills"]]
            extra_txt = st.text_input("Skills extra (separadas por coma)", value=cfg.get("extras_user", ""), key="cvm_extra")
            extras_user = [x.strip() for x in extra_txt.split(",") if x.strip()]
            opciones_sk += [e for e in extras_user if e not in opciones_sk]
            previo = [s for s in cfg.get("skills", []) if s in opciones_sk]
            skills_sel = st.multiselect("Skills activas", opciones_sk, default=previo or cv["skills"], key="cvm_skills")
            anios = st.number_input("Años de experiencia", 0, 30, int(cfg.get("anios", cv["anios"] or 3)), key="cvm_anios")

        data["cfg"] = cfg = {"skills": skills_sel, "anios": int(anios), "extras_user": extra_txt, "queries": queries,
                             "queries_custom": custom_txt, "ubicacion": ubic, "antiguedad": ant_lbl, "paginas": int(pags),
                             "modalidad": modal, "nivel": nivel, "leer": leer, "limite": int(limite)}
        extras_sc = [e for e in cv["extras"] if e in skills_sel] + [e for e in extras_user if e in skills_sel]

        with zona_boton:
            b1, b2 = st.columns([3, 1])
            buscar = b1.button("🚀 Buscar empleos en LinkedIn", type="primary", use_container_width=True, disabled=not queries)
            recalc = b2.button("♻️ Recalcular puntajes", use_container_width=True,
                               help="Aplica tus skills/años actuales a todo lo ya guardado")
        if buscar:
            barra, estado = st.progress(0.0), st.empty()

            def prog(msg, frac):
                estado.markdown(msg)
                barra.progress(min(1.0, max(0.0, frac)))

            ofertas, avisos = buscar_empleos(queries, ubic, ANTIGUEDAD[ant_lbl], int(pags), modal, nivel, prog)
            for a in avisos:
                st.warning(a)
            borradas = set(data.get("eliminadas", []))
            nuevas = [o for o in ofertas if f"empleo:{o['id']}" not in data["items"] and f"empleo:{o['id']}" not in borradas]
            if leer and nuevas:
                nuevas.sort(key=lambda o: -puntuar(o["titulo"], "", cv, skills_sel, anios, extras_sc)["puntaje"])
                leer_detalles(nuevas, int(limite), prog)
            n_add = integrar(data, nuevas)
            repuntuar(data, cv, skills_sel, anios, extras_sc)
            guardar(data)
            barra.progress(1.0)
            estado.success(f"🎉 LinkedIn devolvió {len(ofertas)} · **{n_add} nuevas** guardadas. Míralas en «2. Resultados y seguimiento».")
            if not ofertas and not avisos:
                st.warning("LinkedIn no devolvió resultados. Prueba ampliar la antigüedad o quitar nivel/modalidad.")
        if recalc:
            repuntuar(data, cv, skills_sel, anios, extras_sc)
            guardar(data)
            st.success("Puntajes recalculados.")
        guardar(data)

    skills_sel = data["cfg"].get("skills", cv["skills"])
    anios = data["cfg"].get("anios", cv["anios"])
    extras_sc = [e for e in cv["extras"] if e in skills_sel]

    # ═════════ 2. RESULTADOS ═════════
    with t_res:
        todas = pd.DataFrame(filas(data))
        if todas.empty:
            st.info("Todavía no hay nada guardado. Busca empleos en la pestaña 1 o agrega publicaciones en la 3.")
        else:
            conteo = {g: int(todas["Estado"].isin(est).sum()) for g, est in GRUPOS_ESTADO.items()}
            st.markdown("**Estado**")
            grupo = st.radio("Estado", list(GRUPOS_ESTADO), horizontal=True, key="cvm_f_grupo",
                             format_func=lambda g: f"{g} ({conteo[g]})", label_visibility="collapsed")
            f1, f2, f3 = st.columns([1.1, 1.5, 1.1])
            pl = f1.radio("Parecido a mi CV", list(FILTRO_PUNTAJE), horizontal=True, index=1, key="cvm_f_pun")
            dl = f2.radio("Publicada hace", list(FILTRO_DIAS), horizontal=True, index=len(FILTRO_DIAS) - 1, key="cvm_f_dias")
            tipo = f3.radio("Mostrar", ["Todo", "Empleos", "Publicaciones"], horizontal=True, key="cvm_f_tipo")
            g1, g2 = st.columns([3, 1])
            texto = g1.text_input("Buscar (título, empresa, skill…)", key="cvm_f_txt", placeholder="ej: node, banco, remoto")
            orden = g2.selectbox("Ordenar", ["Mejor puntaje", "Más recientes"], key="cvm_f_ord")

            df = filtrar_df(todas, FILTRO_PUNTAJE[pl], FILTRO_DIAS[dl], tipo, grupo, texto, orden)
            total_est = int(todas["Estado"].isin(GRUPOS_ESTADO[grupo]).sum())
            st.caption(f"Mostrando **{len(df)}** de {total_est} en «{grupo}»"
                       + (f" · {total_est - len(df)} ocultas por los filtros de arriba" if total_est > len(df) else "")
                       + " · 🟢 ≤3 días · 🟡 ≤2 semanas · 🔴 más antiguas")
            if df.empty:
                st.warning("Ningún resultado con estos filtros. Prueba «Todas» en «Parecido a mi CV» o «Publicada hace».")
            else:
                sel_todo = st.checkbox("Seleccionar todas las visibles", key="cvm_selall")
                ed = _tabla(st, df, sel_todo)
                _guardar_ediciones(st, data, ed)
                marcadas = list(ed.loc[ed["Sel"], "_key"])
                st.caption(f"✔ {len(marcadas)} seleccionada(s). Cambia **Estado** o **Notas** directo en la tabla.")
                a1, a2, a3, a4 = st.columns(4)
                if a1.button("👀 Marcar revisada", disabled=not marcadas, use_container_width=True):
                    marcar(data, marcadas, ESTADOS[1]); _refrescar(st, data)
                if a2.button("📨 Marcar postulada", disabled=not marcadas, use_container_width=True):
                    marcar(data, marcadas, ESTADOS[2]); _refrescar(st, data)
                if a3.button("❌ Descartar", disabled=not marcadas, use_container_width=True):
                    marcar(data, marcadas, ESTADO_DESCARTADA); _refrescar(st, data)
                if a4.button("🗑️ Eliminar", disabled=not marcadas, use_container_width=True,
                             help="Borra de lo guardado. Los empleos eliminados no vuelven a aparecer al buscar."):
                    eliminar(data, marcadas); _refrescar(st, data)
                _detalle(st, data, list(df["_key"]))

            with st.expander("🧹 Limpiar lo guardado"):
                st.caption("Los empleos eliminados no vuelven a aparecer en próximas búsquedas (salvo «Eliminar TODO»).")
                k1, k2, k3 = st.columns(3)
                n_desc = int((todas["Estado"] == ESTADO_DESCARTADA).sum())
                if k1.button(f"🗑️ Eliminar descartadas ({n_desc})", disabled=not n_desc, use_container_width=True):
                    eliminar(data, todas.loc[todas["Estado"] == ESTADO_DESCARTADA, "_key"]); _refrescar(st, data)
                lim_p = k2.number_input("Match menor a", 0, 100, 30, key="cvm_lim_p")
                n_bajo = int(((todas["Puntaje"] < lim_p) & (todas["Estado"] == ESTADO_NUEVA)).sum())
                if k2.button(f"🗑️ Eliminar nuevas con match bajo ({n_bajo})", disabled=not n_bajo, use_container_width=True):
                    eliminar(data, todas.loc[(todas["Puntaje"] < lim_p) & (todas["Estado"] == ESTADO_NUEVA), "_key"]); _refrescar(st, data)
                lim_d = k3.number_input("Publicadas hace más de (días)", 1, 365, 30, key="cvm_lim_d")
                n_viejo = int(((todas["_dias"] > lim_d) & (todas["_dias"] < 9999) & (todas["Estado"] == ESTADO_NUEVA)).sum())
                if k3.button(f"🗑️ Eliminar nuevas antiguas ({n_viejo})", disabled=not n_viejo, use_container_width=True):
                    eliminar(data, todas.loc[(todas["_dias"] > lim_d) & (todas["_dias"] < 9999) & (todas["Estado"] == ESTADO_NUEVA), "_key"]); _refrescar(st, data)
                st.markdown("---")
                conf = st.checkbox("Confirmo que quiero borrar TODO lo guardado (empleos, publicaciones, estados y notas)", key="cvm_conf_all")
                if st.button("⚠️ Eliminar TODO", disabled=not conf, type="secondary"):
                    data["items"], data["eliminadas"] = {}, []
                    _refrescar(st, data)
            with st.expander("⬇️ Exportar (CSV)"):
                st.download_button("Descargar lo filtrado", df.drop(columns=["Sel", "_key", "_dias", "_fest", "_tipo"]).to_csv(index=False).encode("utf-8-sig"),
                                   file_name=f"cv_match_{datetime.now():%Y%m%d}.csv", mime="text/csv")

    # ═════════ 3. PUBLICACIONES ═════════
    with t_pub:
        st.info("LinkedIn **no deja buscar publicaciones sin iniciar sesión**, así que no se pueden traer solas. "
                "1) Abre una búsqueda con los botones, 2) copia el texto de los posts que te sirvan, "
                "3) pégalos aquí. Se puntúan y aparecen en «Resultados» con su fecha (filtra con «Mostrar → Publicaciones»).")
        per = st.selectbox("Periodo de la búsqueda en LinkedIn", list(PERIODOS_POST), index=1, key="cvm_per")
        cols = st.columns(2)
        for i, (q, u) in enumerate(urls_busqueda_posts(data["cfg"].get("queries", [])[:6], PERIODOS_POST[per])):
            cols[i % 2].link_button(f"🔗 Posts: {q}", u, use_container_width=True)
        st.markdown("##### ➕ Pegar publicaciones")
        with st.form("cvm_form_post", clear_on_submit=True):
            txt = st.text_area("Texto (si pegas varios, sepáralos con una línea que diga ---)", height=170)
            u1, u2, u3 = st.columns(3)
            fecha_p = u1.date_input("📅 Fecha en que se publicó", value=date.today(), max_value=date.today(),
                                    help="LinkedIn muestra «hace 3 d»: pon esa fecha. Se usa para saber qué tan actual es.")
            autor = u2.text_input("Autor / empresa (opcional)")
            url_p = u3.text_input("URL del post (opcional, solo si pegas uno)")
            enviado = st.form_submit_button("Evaluar y guardar", type="primary")
        if enviado and txt.strip():
            partes = dividir_posts(txt)
            nuevos, resumen = [], []
            for parte in partes:
                ana = analizar_publicacion(parte)
                pid = hashlib.md5((url_p if len(partes) == 1 and url_p else parte).encode("utf-8")).hexdigest()[:12]
                nuevos.append({"id": pid, "tipo": "publicacion", "titulo": parte.splitlines()[0][:120], "empresa": autor, "lugar": "",
                               "fecha": fecha_p.isoformat(), "url": url_p if len(partes) == 1 else "", "desc": parte, "emails": ana["emails"]})
            integrar(data, nuevos)
            repuntuar(data, cv, skills_sel, anios, extras_sc)
            guardar(data)
            for n in nuevos:
                sc = data["items"].get(f"publicacion:{n['id']}", {}).get("score", {})
                ana = analizar_publicacion(n["desc"])
                resumen.append(f"- **{sc.get('puntaje', 0)}/100** · {n['titulo'][:70]} · "
                               + ("🟢 parece oferta" if ana["contratando"] else "🟡 sin lenguaje de contratación")
                               + (f" · ✉️ {', '.join(ana['emails'])}" if ana["emails"] else ""))
            st.success(f"{len(nuevos)} publicación(es) guardada(s) con fecha {fecha_p:%d-%m-%Y}. Revísalas en «Resultados».")
            st.markdown("\n".join(resumen))
